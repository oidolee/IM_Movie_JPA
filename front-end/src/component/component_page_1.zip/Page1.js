import React, {Component} from 'react';

class MainBody extends Component{
    render(){
        return(
            <div>
               Page2222
            </div>
        );
    }
}

export default MainBody;